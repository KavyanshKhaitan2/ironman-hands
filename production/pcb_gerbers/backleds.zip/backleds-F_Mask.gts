G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.0*
G04 #@! TF.CreationDate,2026-05-26T21:09:56+05:30*
G04 #@! TF.ProjectId,backleds,6261636b-6c65-4647-932e-6b696361645f,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.0) date 2026-05-26 21:09:56*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10R,1.700000X1.700000*%
%ADD11C,1.700000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J3*
X123711221Y-106408779D03*
D11*
X126251221Y-106408779D03*
X128791221Y-106408779D03*
G04 #@! TD*
M02*
